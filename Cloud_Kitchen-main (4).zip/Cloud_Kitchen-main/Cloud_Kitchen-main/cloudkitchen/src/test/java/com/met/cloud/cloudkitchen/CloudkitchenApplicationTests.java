package com.met.cloud.cloudkitchen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudkitchenApplicationTests {

	@Test
	void contextLoads() {
	}

}
