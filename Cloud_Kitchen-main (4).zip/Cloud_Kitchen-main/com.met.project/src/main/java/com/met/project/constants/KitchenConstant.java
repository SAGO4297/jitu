package com.met.project.constants;

public class KitchenConstant {
	
	public static final String SOMETHING_WENT_WRONG= "Something Went Wrong.";
	
	public static final String INVALID_DATA = "Invalid Data";
	
}
