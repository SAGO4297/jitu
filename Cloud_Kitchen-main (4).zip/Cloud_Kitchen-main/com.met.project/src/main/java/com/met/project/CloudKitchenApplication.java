package com.met.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudKitchenApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudKitchenApplication.class, args);
	}

}
